prodeuct 테이블
{id, name, price, quantity}
crud
create: 상품 만들기
read: 상품 전체, 상품 상세
update: 일부 수정
delete: 상품 삭제
